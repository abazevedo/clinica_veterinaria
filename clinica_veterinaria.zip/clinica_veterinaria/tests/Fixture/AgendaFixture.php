<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * AgendaFixture
 */
class AgendaFixture extends TestFixture
{
    /**
     * Table name
     *
     * @var string
     */
    public $table = 'agenda';
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'autoIncrement' => true, 'precision' => null],
        'data_consulta' => ['type' => 'date', 'length' => null, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null],
        'hora_consulta' => ['type' => 'time', 'length' => null, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null],
        'veterinario_id' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'paciente_id' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        '_indexes' => [
            'FK_veterinario' => ['type' => 'index', 'columns' => ['veterinario_id'], 'length' => []],
            'FK_paciente' => ['type' => 'index', 'columns' => ['paciente_id'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id'], 'length' => []],
            'agenda_ibfk_1' => ['type' => 'foreign', 'columns' => ['veterinario_id'], 'references' => ['veterinario', 'id'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'agenda_ibfk_2' => ['type' => 'foreign', 'columns' => ['paciente_id'], 'references' => ['paciente', 'id'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'utf8_general_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id' => 1,
                'data_consulta' => '2022-06-23',
                'hora_consulta' => '01:26:18',
                'veterinario_id' => 1,
                'paciente_id' => 1
            ],
        ];
        parent::init();
    }
}
