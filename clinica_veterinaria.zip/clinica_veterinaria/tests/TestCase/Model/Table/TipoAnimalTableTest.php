<?php
namespace App\Test\TestCase\Model\Table;

use App\Model\Table\TipoAnimalTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\TipoAnimalTable Test Case
 */
class TipoAnimalTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\TipoAnimalTable
     */
    public $TipoAnimal;

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'app.TipoAnimal',
        'app.Paciente'
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $config = TableRegistry::getTableLocator()->exists('TipoAnimal') ? [] : ['className' => TipoAnimalTable::class];
        $this->TipoAnimal = TableRegistry::getTableLocator()->get('TipoAnimal', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->TipoAnimal);

        parent::tearDown();
    }

    /**
     * Test initialize method
     *
     * @return void
     */
    public function testInitialize()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
