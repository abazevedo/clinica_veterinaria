<?php
namespace App\Test\TestCase\Model\Table;

use App\Model\Table\VeterinarioTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\VeterinarioTable Test Case
 */
class VeterinarioTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\VeterinarioTable
     */
    public $Veterinario;

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'app.Veterinario',
        'app.Agenda'
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $config = TableRegistry::getTableLocator()->exists('Veterinario') ? [] : ['className' => VeterinarioTable::class];
        $this->Veterinario = TableRegistry::getTableLocator()->get('Veterinario', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->Veterinario);

        parent::tearDown();
    }

    /**
     * Test initialize method
     *
     * @return void
     */
    public function testInitialize()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
