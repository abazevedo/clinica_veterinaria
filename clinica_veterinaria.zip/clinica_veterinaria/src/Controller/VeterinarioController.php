<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Veterinario Controller
 *
 * @property \App\Model\Table\VeterinarioTable $Veterinario
 *
 * @method \App\Model\Entity\Veterinario[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class VeterinarioController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $veterinario = $this->paginate($this->Veterinario);

        $this->set(compact('veterinario'));
    }

    /**
     * View method
     *
     * @param string|null $id Veterinario id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $veterinario = $this->Veterinario->get($id, [
            'contain' => ['Agenda' => ['Paciente']]
        ]);

        $this->set('veterinario', $veterinario);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $veterinario = $this->Veterinario->newEntity();
        if ($this->request->is('post')) {
            $veterinario = $this->Veterinario->patchEntity($veterinario, $this->request->getData());
            if ($this->Veterinario->save($veterinario)) {
                $this->Flash->success(__('The veterinario has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The veterinario could not be saved. Please, try again.'));
        }
        $this->set(compact('veterinario'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Veterinario id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $veterinario = $this->Veterinario->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $veterinario = $this->Veterinario->patchEntity($veterinario, $this->request->getData());
            if ($this->Veterinario->save($veterinario)) {
                $this->Flash->success(__('The veterinario has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The veterinario could not be saved. Please, try again.'));
        }
        $this->set(compact('veterinario'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Veterinario id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $veterinario = $this->Veterinario->get($id);
        if ($this->Veterinario->delete($veterinario)) {
            $this->Flash->success(__('The veterinario has been deleted.'));
        } else {
            $this->Flash->error(__('The veterinario could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
