<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * TipoAnimal Controller
 *
 * @property \App\Model\Table\TipoAnimalTable $TipoAnimal
 *
 * @method \App\Model\Entity\TipoAnimal[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class TipoAnimalController extends AppController
{
	
	public $paginate = [
        'limit' => 10,
        'order' => [
            'TipoAnimal.tipo' => 'asc'
        ]
    ];	
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {	
        $tipoAnimal = $this->paginate($this->TipoAnimal);

        $this->set(compact('tipoAnimal'));
    }

    /**
     * View method
     *
     * @param string|null $id Tipo Animal id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $tipoAnimal = $this->TipoAnimal->get($id, [
            'contain' => ['Paciente']
        ]);

        $this->set('tipoAnimal', $tipoAnimal);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $tipoAnimal = $this->TipoAnimal->newEntity();
        if ($this->request->is('post')) {
            $tipoAnimal = $this->TipoAnimal->patchEntity($tipoAnimal, $this->request->getData());
            if ($this->TipoAnimal->save($tipoAnimal)) {
                $this->Flash->success(__('The tipo animal has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The tipo animal could not be saved. Please, try again.'));
        }
        $this->set(compact('tipoAnimal'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Tipo Animal id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $tipoAnimal = $this->TipoAnimal->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $tipoAnimal = $this->TipoAnimal->patchEntity($tipoAnimal, $this->request->getData());
            if ($this->TipoAnimal->save($tipoAnimal)) {
                $this->Flash->success(__('The tipo animal has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The tipo animal could not be saved. Please, try again.'));
        }
        $this->set(compact('tipoAnimal'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Tipo Animal id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $tipoAnimal = $this->TipoAnimal->get($id);
        if ($this->TipoAnimal->delete($tipoAnimal)) {
            $this->Flash->success(__('The tipo animal has been deleted.'));
        } else {
            $this->Flash->error(__('The tipo animal could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
