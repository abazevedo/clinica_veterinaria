<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Paciente Controller
 *
 * @property \App\Model\Table\PacienteTable $Paciente
 *
 * @method \App\Model\Entity\Paciente[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class PacienteController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['TipoAnimal']
        ];
        $paciente = $this->paginate($this->Paciente);

        $this->set(compact('paciente'));
    }

    /**
     * View method
     *
     * @param string|null $id Paciente id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $paciente = $this->Paciente->get($id, [
            'contain' => ['TipoAnimal', 'Agenda']
        ]);

        $this->set('paciente', $paciente);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $paciente = $this->Paciente->newEntity();
        if ($this->request->is('post')) {
            $paciente = $this->Paciente->patchEntity($paciente, $this->request->getData());
            if ($this->Paciente->save($paciente)) {
                $this->Flash->success(__('The paciente has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The paciente could not be saved. Please, try again.'));
        }
        $tipoAnimal = $this->Paciente->TipoAnimal->find('list', ['keyField' => 'id', 'valueField' => 'tipo', 'limit' => 200]);
        $this->set(compact('paciente', 'tipoAnimal'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Paciente id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $paciente = $this->Paciente->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $paciente = $this->Paciente->patchEntity($paciente, $this->request->getData());
            if ($this->Paciente->save($paciente)) {
                $this->Flash->success(__('The paciente has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The paciente could not be saved. Please, try again.'));
        }
        $tipoAnimal = $this->Paciente->TipoAnimal->find('list', ['keyField' => 'id', 'valueField' => 'tipo', 'limit' => 200]);
        $this->set(compact('paciente', 'tipoAnimal'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Paciente id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $paciente = $this->Paciente->get($id);
        if ($this->Paciente->delete($paciente)) {
            $this->Flash->success(__('The paciente has been deleted.'));
        } else {
            $this->Flash->error(__('The paciente could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
