<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\I18n\I18n;

/**
 * Agenda Controller
 *
 * @property \App\Model\Table\AgendaTable $Agenda
 *
 * @method \App\Model\Entity\Agenda[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class AgendaController extends AppController
{
	public $paginate = [
        'limit' => 10,
		'sortWhitelist' => [
			'data_consulta',
			'hora_consulta',
			'Veterinario.nome',
            'Paciente.nome',
			'Paciente.nome_responsavel',
			'TipoAnimal.tipo'            
		]
	];
	
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $veterinario = $this->Agenda->Veterinario->find('list', ['keyField' => 'id', 'valueField' => 'nome', 'limit' => 200]);
		$tipoAnimal = $this->Agenda->Paciente->TipoAnimal->find('list', ['keyField' => 'id', 'valueField' => 'tipo', 'limit' => 200]);
		
		$condicoes = [];
		if(!empty($this->request->getQuery('veterinario'))){
			$condicoes['Veterinario.id'] = $this->request->getQuery('veterinario');
		}
		if(!empty($this->request->getQuery('tipo'))){
			$condicoes['TipoAnimal.id'] = $this->request->getQuery('tipo');
		}
		if(!empty($this->request->getQuery('paciente'))){
			$condicoes['Paciente.nome LIKE'] = '%'. $this->request->getQuery('paciente') .'%';
		}
		$condicoes['data_consulta >='] = date("Y-m-d");
			
		$query = $this->Agenda->find()->where($condicoes)->contain(['Veterinario', 'Paciente' => ['TipoAnimal']]);

        $agenda = $this->paginate($query);
		
		$this->set(compact('agenda', 'veterinario', 'tipoAnimal'));
    }

	
	 public function listaConsultas()
    {
		$veterinario = $this->Agenda->Veterinario->find('list', ['keyField' => 'id', 'valueField' => 'nome', 'limit' => 200]);
		$tipoAnimal = $this->Agenda->Paciente->TipoAnimal->find('list', ['keyField' => 'id', 'valueField' => 'tipo', 'limit' => 200]);
		
		$condicoes = [];
		if(!empty($this->request->getQuery('veterinario'))){
			$condicoes['Veterinario.id'] = $this->request->getQuery('veterinario');
		}
		if(!empty($this->request->getQuery('tipo'))){
			$condicoes['TipoAnimal.id'] = $this->request->getQuery('tipo');
		}
		if(!empty($this->request->getQuery('paciente'))){
			$condicoes['Paciente.nome LIKE'] = '%'. $this->request->getQuery('paciente') .'%';
		}
		$condicoes['data_consulta >='] = date("Y-m-d");
			
		$query = $this->Agenda->find()->where($condicoes)->contain(['Veterinario', 'Paciente' => ['TipoAnimal']]);

        $agenda = $this->paginate($query);
		
		$this->set(compact('agenda', 'veterinario', 'tipoAnimal'));
    }

    /**
     * View method
     *
     * @param string|null $id Agenda id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $agenda = $this->Agenda->get($id, [
            'contain' => ['Veterinario', 'Paciente']
        ]);

        $this->set('agenda', $agenda);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $agenda = $this->Agenda->newEntity();
        if ($this->request->is('post')) {
            $agenda = $this->Agenda->patchEntity($agenda, $this->request->getData());
            if ($this->Agenda->save($agenda)) {
                $this->Flash->success(__('Consulta salva.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('Não foi possível salvar.'));
        }
        $veterinario = $this->Agenda->Veterinario->find('list', ['keyField' => 'id', 'valueField' => 'nome', 'limit' => 200]);
        $paciente = $this->Agenda->Paciente->find('list', ['keyField' => 'id', 'valueField' => 'nome','limit' => 200]);
        $this->set(compact('agenda', 'veterinario', 'paciente'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Agenda id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $agenda = $this->Agenda->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $agenda = $this->Agenda->patchEntity($agenda, $this->request->getData());
            if ($this->Agenda->save($agenda)) {
                $this->Flash->success(__('Consulta salva.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('Não foi possível salvar.'));
        }
        $veterinario = $this->Agenda->Veterinario->find('list', ['keyField' => 'id', 'valueField' => 'nome', 'limit' => 200]);
        $paciente = $this->Agenda->Paciente->find('list', ['keyField' => 'id', 'valueField' => 'nome','limit' => 200]);
        $this->set(compact('agenda', 'veterinario', 'paciente'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Agenda id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $agenda = $this->Agenda->get($id);
        if ($this->Agenda->delete($agenda)) {
            $this->Flash->success(__('Consulta excluída.'));
        } else {
            $this->Flash->error(__('Consulta não pode ser excluída.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
