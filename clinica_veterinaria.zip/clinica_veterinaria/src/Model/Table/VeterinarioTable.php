<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Veterinario Model
 *
 * @property \App\Model\Table\AgendaTable|\Cake\ORM\Association\HasMany $Agenda
 *
 * @method \App\Model\Entity\Veterinario get($primaryKey, $options = [])
 * @method \App\Model\Entity\Veterinario newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Veterinario[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Veterinario|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Veterinario saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Veterinario patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Veterinario[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Veterinario findOrCreate($search, callable $callback = null, $options = [])
 */
class VeterinarioTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('veterinario');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->hasMany('Agenda', [
            'foreignKey' => 'veterinario_id'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmptyString('id', 'create');

        $validator
            ->scalar('nome')
            ->maxLength('nome', 50)
            ->requirePresence('nome', 'create')
            ->allowEmptyString('nome', false);

        $validator
            ->integer('crv')
            ->requirePresence('crv', 'create')
            ->allowEmptyString('crv', false);

        return $validator;
    }
}
