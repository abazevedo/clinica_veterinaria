<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Agenda Model
 *
 * @property \App\Model\Table\VeterinarioTable|\Cake\ORM\Association\BelongsTo $Veterinario
 * @property \App\Model\Table\PacienteTable|\Cake\ORM\Association\BelongsTo $Paciente
 *
 * @method \App\Model\Entity\Agenda get($primaryKey, $options = [])
 * @method \App\Model\Entity\Agenda newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Agenda[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Agenda|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Agenda saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Agenda patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Agenda[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Agenda findOrCreate($search, callable $callback = null, $options = [])
 */
class AgendaTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('agenda');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->belongsTo('Veterinario', [
            'foreignKey' => 'veterinario_id',
            'joinType' => 'INNER'
        ]);
        $this->belongsTo('Paciente', [
            'foreignKey' => 'paciente_id',
            'joinType' => 'INNER'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmptyString('id', 'create');

        $validator
            ->date('data_consulta')
            ->requirePresence('data_consulta', 'create')
            ->allowEmptyDate('data_consulta', false);

        $validator
            ->time('hora_consulta')
            ->requirePresence('hora_consulta', 'create')
            ->allowEmptyTime('hora_consulta', false);

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['veterinario_id'], 'Veterinario'));
        $rules->add($rules->existsIn(['paciente_id'], 'Paciente'));

        return $rules;
    }
}
