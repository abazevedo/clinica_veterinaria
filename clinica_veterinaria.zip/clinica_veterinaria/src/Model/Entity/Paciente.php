<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Paciente Entity
 *
 * @property int $id
 * @property string $nome
 * @property string $nome_responsavel
 * @property int $idade
 * @property int $tipo_animal_id
 *
 * @property \App\Model\Entity\TipoAnimal $tipo_animal
 * @property \App\Model\Entity\Agenda[] $agenda
 */
class Paciente extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'nome' => true,
        'nome_responsavel' => true,
        'idade' => true,
        'tipo_animal_id' => true,
        'tipo_animal' => true,
        'agenda' => true
    ];
}
